-- phpMyAdmin SQL Dump
-- version 6.0.0-dev
-- https://www.phpmyadmin.net/
--
-- Host: 192.168.30.23
-- Czas generowania: 13 Mar 2023, 12:35
-- Wersja serwera: 8.0.18
-- Wersja PHP: 8.2.3
SET
    SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

START TRANSACTION;

SET
    time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */
;

/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */
;

/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */
;

/*!40101 SET NAMES utf8mb4 */
;

--
-- Baza danych: `Bd`
--
-- --------------------------------------------------------
--
-- Struktura tabeli dla tabeli `message`
--
CREATE TABLE `message` (
    `id` int(11) NOT NULL,
    `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_polish_ci NOT NULL COMMENT 'name of the message',
    `type` varchar(20) CHARACTER SET utf8 COLLATE utf8_polish_ci DEFAULT NULL COMMENT 'type of the message\r\n(private/public)',
    `message` varchar(2000) CHARACTER SET utf8 COLLATE utf8_polish_ci NOT NULL COMMENT 'message text',
    `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'existing message - 0, deleted - 1'
) ENGINE = InnoDB DEFAULT CHARSET = utf8 COLLATE = utf8_polish_ci;

--
-- Zrzut danych tabeli `message`
--
INSERT INTO
    `message` (`id`, `name`, `type`, `message`, `deleted`)
VALUES
    (
        1,
        'New Intel technology',
        'public',
        'Intel has announced a new processor for desktops',
        0
    ),
    (
        2,
        'Intel shares raising',
        'private',
        'brokers announce: Intel shares will go up!',
        0
    ),
    (
        3,
        'New graphic card from NVidia',
        'public',
        'NVidia has announced a new graphic card for desktops',
        0
    ),
    (
        4,
        'Airplane crash',
        'public',
        'A passenger plane has crashed in Europe',
        0
    ),
    (
        5,
        'Coronavirus',
        'private',
        'A new version of virus was found!',
        0
    ),
    (
        6,
        'Bitcoin price raises',
        'public',
        'Price of bitcoin reaches new record.',
        0
    ),
    (
        9,
        'New Windows announced',
        'public',
        'A new version of windows was announced. Present buyers of Widows\r\n10 can update the system to the newest version for free.',
        0
    );

-- --------------------------------------------------------
--
-- Struktura tabeli dla tabeli `user`
--
CREATE TABLE `user` (
    `id` int(11) NOT NULL,
    `login` varchar(30) CHARACTER SET utf8 COLLATE utf8_polish_ci NOT NULL,
    `email` varchar(60) CHARACTER SET utf8 COLLATE utf8_polish_ci NOT NULL,
    `hash` varchar(255) CHARACTER SET utf8 COLLATE utf8_polish_ci NOT NULL COMMENT 'password hash or HMAC value',
    `salt` blob COMMENT 'salt to use in password hashing',
    `sms_code` varchar(6) CHARACTER SET utf8 COLLATE utf8_polish_ci DEFAULT NULL COMMENT 'security code sent via\r\nsms or e-mail',
    `code_timelife` timestamp NULL DEFAULT NULL COMMENT 'timelife of security code',
    `security_question` varchar(255) CHARACTER SET utf8 COLLATE utf8_polish_ci DEFAULT NULL COMMENT 'additional\r\nsecurity question used while password recovering',
    `answer` varchar(255) CHARACTER SET utf8 COLLATE utf8_polish_ci DEFAULT NULL COMMENT 'security question answer',
    `lockout_time` timestamp NULL DEFAULT NULL COMMENT 'time to which user account is blocked',
    `session_id` blob COMMENT 'user session identifier',
    `id_status` int(11) NOT NULL COMMENT 'account status',
    `password_form` int(11) NOT NULL DEFAULT '1' COMMENT '1- SHA512, 2-SHA512+salt,3- HMAC'
) ENGINE = InnoDB DEFAULT CHARSET = utf8 COLLATE = utf8_polish_ci;

--
-- Zrzut danych tabeli `user`
--
INSERT INTO
    `user` (
        `id`,
        `login`,
        `email`,
        `hash`,
        `salt`,
        `sms_code`,
        `code_timelife`,
        `security_question`,
        `answer`,
        `lockout_time`,
        `session_id`,
        `id_status`,
        `password_form`
    )
VALUES
    (
        1,
        'john',
        'johny@gmail.com',
        '552d29f9290b9521e6016c2296fa4511',
        0x734635256752,
        '345543',
        '2022-01-05 13:25:36',
        'Your friend\'s name?',
        'Peter',
        NULL,
        NULL,
        2,
        1
    ),
    (
        2,
        'susie',
        'susie@gmail.com',
        '8c90f286786c7f3b96564e1e88e0ddab',
        0x6a363752,
        '674545',
        '2022-01-12 13:25:36',
        'Where were you on your 2015\'s holiday?',
        'Turkey',
        NULL,
        NULL,
        5,
        1
    ),
    (
        3,
        'anie',
        'anie@gmail.com',
        'dcb710a566c2a24c8bfaf83618e728f7',
        0x73646667683534,
        NULL,
        NULL,
        'Your favorite\r\ncolor?',
        'Navy blue',
        NULL,
        NULL,
        1,  
        1
    );

--
-- Indeksy dla zrzutów tabel
--
--
-- Indeksy dla tabeli `message`
--
ALTER TABLE
    `message`
ADD
    PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `user`
--
ALTER TABLE
    `user`
ADD
    PRIMARY KEY (`id`),
ADD
    UNIQUE KEY `login` (`login`),
ADD
    UNIQUE KEY `email` (`email`),
ADD
    KEY `FKuser674283` (`id_status`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--
--
-- AUTO_INCREMENT dla tabeli `message`
--
ALTER TABLE
    `message`
MODIFY
    `id` int(11) NOT NULL AUTO_INCREMENT,
    AUTO_INCREMENT = 10;

--
-- AUTO_INCREMENT dla tabeli `user`
--
ALTER TABLE
    `user`
MODIFY
    `id` int(11) NOT NULL AUTO_INCREMENT,
    AUTO_INCREMENT = 4;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */
;

/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */
;

/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */
;