<?php
include_once "classes/Page.php";
include_once "classes/Bd.php";
Page::display_header("Edit Message");

if (isset($_REQUEST['id'])) {
  $id = $_REQUEST['id'];
} else {
  echo "Invalid message ID";
  exit;
}

    

$db = new Db("localhost", "root", "", "bd");

if (isset($_REQUEST['update_message'])) {
  $content = $_REQUEST['content'];
  if (!$db->updateMessage($id, $content)) {
    echo "Updating message failed";
  }
}
?>

<hr>
<form action="edit_message.php" method="POST">
  <input type="hidden" name="id" value="<?php echo $id; ?>">
  <textarea name="content"><?php echo $db->getMessage($id); ?></textarea>
  <br>
  <input type="submit" name="update_message" value="Update">
</form>
<hr>

<?php Page::display_navigation(); ?>
</body>
</html>
