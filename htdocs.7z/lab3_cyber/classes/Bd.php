<?php

class Db {
    private $pdo; // Database variable
    private $select_result; // Result

    public function __construct($serwer, $user, $pass, $baza) {
        try {
            $this->pdo = new PDO("mysql:host=$serwer;dbname=$baza;charset=utf8mb4", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "Connection to server failed: " . $e->getMessage();
            exit();
        }
    }

    public function __destruct() {
        $this->pdo = null;
    }

    public function select($sql) {
        // Parameter $sql – select string
        // Variable $results – association table with querry results
        $results = array();

        try {
            $stmt = $this->pdo->query($sql);
            $results = $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Error during select query: " . $e->getMessage();
        }

        $this->select_result = $results;
        return $results;
    }

    public function addMessage($name, $type, $content) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO message (`name`,`type`, `message`,`deleted`) VALUES (:name, :type, :content, 0)");
            $stmt->bindParam(':name', $name, PDO::PARAM_STR);
            $stmt->bindParam(':type', $type, PDO::PARAM_STR);
            $stmt->bindParam(':content', $content, PDO::PARAM_STR);
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            echo "Error during insert query: " . $e->getMessage();
            return false;
        }
    }

    public function getMessage($message_id) {
        try {
            $stmt = $this->pdo->prepare("SELECT message FROM message WHERE id = :id");
            $stmt->bindParam(':id', $message_id, PDO::PARAM_INT);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_OBJ);
            return $result ? $result->message : "";
        } catch (PDOException $e) {
            echo "Error during select query: " . $e->getMessage();
            return "";
        }
    }

    public function updateMessage($message_id, $content) {
        $key = substr($content, 0, 1) == 'I' ? 'private' : 'public';
        try {
            $stmt = $this->pdo->prepare("UPDATE message SET message = :content, `type` = :type WHERE id = :id");
            $stmt->bindParam(':content', $content, PDO::PARAM_STR);
            $stmt->bindParam(':type', $key, PDO::PARAM_STR);
            $stmt->bindParam(':id', $message_id, PDO::PARAM_INT);
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            echo "Error during update query: " . $e->getMessage();
            return false;
        }
    }
}
    