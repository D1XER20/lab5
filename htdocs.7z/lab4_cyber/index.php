<?php
include_once "classes/Page.php";
Page::display_header("Main page");
?>
<H2> Main page</H2>
<?php
Page::display_navigation();
?>
 </body>
</html>